"""Implement these functions for the selected video API provider.

Keep the provider API key on the server. Never ship it in the Android app.
"""
async def submit_to_provider(payload: dict):
    # TODO: call the chosen provider's documented create-generation endpoint.
    # Return the provider's job identifier and any metadata needed for polling.
    raise NotImplementedError("Configure a provider adapter in backend/provider.py")

async def get_provider_job(provider_job: dict):
    # TODO: query provider job status and normalize it to:
    # {"status": "queued|processing|succeeded|failed", "video_url": "...", "error": "..."}
    raise NotImplementedError("Configure a provider adapter in backend/provider.py")
