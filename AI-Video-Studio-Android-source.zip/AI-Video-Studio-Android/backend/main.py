from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from uuid import uuid4
from provider import submit_to_provider, get_provider_job

app = FastAPI(title="AI Video Studio API", version="0.1.0")
jobs = {}  # Demo only. Use a persistent database/queue in production.

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=4000)
    aspect_ratio: str = "9:16"
    duration_seconds: int = Field(default=5, ge=3, le=60)
    style: str = "cinematic"

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/v1/generations")
async def create_generation(request: GenerateRequest):
    try:
        provider_job = await submit_to_provider(request.model_dump())
    except NotImplementedError:
        raise HTTPException(501, "Video provider adapter is not configured")
    except Exception as exc:
        raise HTTPException(502, f"Provider error: {type(exc).__name__}")
    job_id = str(uuid4())
    jobs[job_id] = provider_job
    return {"id": job_id, "status": "submitted"}

@app.get("/v1/generations/{job_id}")
async def generation_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Generation not found")
    try:
        result = await get_provider_job(jobs[job_id])
    except NotImplementedError:
        raise HTTPException(501, "Video provider adapter is not configured")
    return {"id": job_id, **result}
