package ru.aivideostudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter

private val Ink = Color(0xFF10131D)
private val Panel = Color(0xFF1B2030)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFFADB4C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioApp() {
    var prompt by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("9:16") }
    var duration by remember { mutableStateOf("5 секунд") }
    var style by remember { mutableStateOf("Кинореализм") }
    var tab by remember { mutableStateOf(0) }
    var backendUrl by remember { mutableStateOf("https://YOUR-SERVER.example.com") }
    var status by remember { mutableStateOf("Готово к работе") }
    var busy by remember { mutableStateOf(false) }
    var freePrompt by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Ink,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Movie, null) }, label = { Text("Создать") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Collections, null) }, label = { Text("Мои видео") }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") }
                    )
                }
            }
        ) { padding ->
            when (tab) {
                0 -> CreateScreen(
                    modifier = Modifier.padding(padding),
                    prompt = prompt, onPrompt = { prompt = it },
                    ratio = ratio, onRatio = { ratio = it },
                    duration = duration, onDuration = { duration = it },
                    style = style, onStyle = { style = it },
                    status = status, busy = busy,
                    onFree = {
                        freePrompt = buildString {
                            appendLine("Стиль: $style. Формат: $ratio. Длительность: $duration.")
                            appendLine(prompt.trim())
                            appendLine("Кинематографичная композиция, плавное движение камеры, естественное освещение, последовательность сцен.")
                        }
                        status = "Промпт подготовлен. Бесплатный режим не рендерит видео."
                    },
                    onGenerate = {
                        if (prompt.isBlank()) {
                            status = "Сначала опиши видео."
                        } else if (backendUrl.contains("YOUR-SERVER")) {
                            status = "Укажи адрес своего сервера во вкладке «Настройки»."
                        } else {
                            busy = true
                            status = "Отправляем задачу на сервер…"
                        }
                    },
                    freePrompt = freePrompt
                )
                1 -> SimplePage(
                    modifier = Modifier.padding(padding),
                    title = "Мои видео",
                    body = "Здесь будут отображаться готовые ролики и история генераций. Подключение хранилища и загрузки видео добавляется на следующем этапе."
                )
                else -> SettingsScreen(
                    modifier = Modifier.padding(padding),
                    backendUrl = backendUrl,
                    onBackendUrl = { backendUrl = it },
                    status = status
                )
            }
        }
    }
}

@Composable
fun CreateScreen(
    modifier: Modifier, prompt: String, onPrompt: (String) -> Unit,
    ratio: String, onRatio: (String) -> Unit,
    duration: String, onDuration: (String) -> Unit,
    style: String, onStyle: (String) -> Unit,
    status: String, busy: Boolean, onFree: () -> Unit,
    onGenerate: () -> Unit, freePrompt: String
) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("AI VIDEO STUDIO", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("Твоя студия видео с искусственным интеллектом", color = Muted, fontSize = 12.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Опиши своё видео", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OutlinedTextField(
                    value = prompt, onValueChange = onPrompt,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                    placeholder = { Text("Например: одинокий путник идёт по заснеженной дороге на рассвете…") },
                    minLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Muted,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Text("Формат", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("9:16", "16:9", "1:1").forEach { item ->
                        FilterChip(selected = ratio == item, onClick = { onRatio(item) }, label = { Text(item) })
                    }
                }
                Text("Длительность", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("5 секунд", "10 секунд", "15 секунд").forEach { item ->
                        FilterChip(selected = duration == item, onClick = { onDuration(item) }, label = { Text(item) })
                    }
                }
                Text("Визуальный стиль", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Кинореализм", "Аниме", "Мультфильм").forEach { item ->
                        FilterChip(selected = style == item, onClick = { onStyle(item) }, label = { Text(item) })
                    }
                }
                Button(onClick = onFree, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
                    Text("Подготовить промпт бесплатно")
                }
                Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                    Text(if (busy) "Отправка…" else "Сгенерировать видео")
                }
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
        if (freePrompt.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Подготовленный промпт", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(freePrompt, color = Muted)
                }
            }
        }
        Text("Бесплатный режим помогает готовить промпты. Рендеринг видео выполняется подключённой ИИ-моделью и может быть платным.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SimplePage(modifier: Modifier, title: String, body: String) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Text(body, Modifier.padding(16.dp), color = Muted)
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, backendUrl: String, onBackendUrl: (String) -> Unit, status: String) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Настройки", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Адрес API-сервера", color = Muted)
        OutlinedTextField(
            value = backendUrl, onValueChange = onBackendUrl,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("https://api.example.com") },
            singleLine = true
        )
        Text("Сервер должен предоставлять защищённый HTTPS API. Секретные ключи видеомоделей вводятся и хранятся на сервере, не в приложении.", color = Muted, fontSize = 12.sp)
        Text("Состояние: $status", color = Muted)
    }
}
